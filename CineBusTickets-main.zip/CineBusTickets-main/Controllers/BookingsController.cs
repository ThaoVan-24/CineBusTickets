using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using CineBusTickets.Models;

namespace CineBusTickets.Controllers
{
    public class BookingsController : Controller
    {
        private readonly CineBusDbContext _context;

        public BookingsController(CineBusDbContext context)
        {
            _context = context;
        }

        // GET: Bookings
        public async Task<IActionResult> Index()
        {
            return View(await _context.Bookings.ToListAsync());
        }

        // GET: Mở giao diện chọn ghế cho vai trò người dùng
        public async Task<IActionResult> BookTicket(int? id)
        {
            if (id == null) return NotFound();

            var trip = await _context.Trips
                .Include(t => t.Bus)
                .Include(t => t.Route)
                .FirstOrDefaultAsync(m => m.Id == id);

            if (trip == null) return NotFound();

            // Lấy danh sách các ghế đã có người đặt trên chuyến này để bôi xám
            var bookedSeats = await _context.BookingItems
                .Where(b => b.TripId == id)
                .Select(b => b.SeatNumber)
                .ToListAsync();

            ViewBag.BookedSeats = bookedSeats;
            return View(trip);
        }

        // POST: Xử lý lưu thông tin đặt vé vào CSDL
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ConfirmBooking(int TripId, string CustomerName, string Phone, string Email, string PickupDropoffLocation, List<string> SelectedSeats)
        {
            if (SelectedSeats == null || !SelectedSeats.Any())
            {
                return RedirectToAction(nameof(BookTicket), new { id = TripId });
            }

            var trip = await _context.Trips.FindAsync(TripId);
            if (trip == null) return NotFound();

            var alreadyBooked = await _context.BookingItems
                .Where(b => b.TripId == TripId && SelectedSeats.Contains(b.SeatNumber))
                .AnyAsync();

            if (alreadyBooked)
            {
                return RedirectToAction(nameof(BookTicket), new { id = TripId });
            }

            var booking = new Booking
            {
                CustomerName = CustomerName,
                Phone = Phone,
                Email = Email,
                PickupDropoffLocation = PickupDropoffLocation,
                TotalPrice = SelectedSeats.Count * trip.TicketPrice,
                Status = "Chờ thanh toán",
                BookingDate = DateTime.Now
            };

            _context.Bookings.Add(booking);
            await _context.SaveChangesAsync();

            foreach (var seat in SelectedSeats)
            {
                var bookingItem = new BookingItem
                {
                    BookingId = booking.Id,
                    TripId = TripId,
                    SeatNumber = seat,
                    Price = trip.TicketPrice
                };
                _context.BookingItems.Add(bookingItem);
            }

            await _context.SaveChangesAsync();

            return RedirectToAction("Index", "Home");
        }

        // GET: Bookings/Details/5 (ĐÃ ĐƯỢC CẬP NHẬT LOGIC LẤY MÃ GHẾ)
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null) return NotFound();

            var booking = await _context.Bookings.FirstOrDefaultAsync(m => m.Id == id);
            if (booking == null) return NotFound();

            var bookingItems = await _context.BookingItems
                .Include(b => b.Trip)
                .ThenInclude(t => t.Route)
                .Where(b => b.BookingId == id)
                .ToListAsync();

            ViewBag.Items = bookingItems;
            return View(booking);
        }

        // POST: Admin thay đổi trạng thái đơn hàng (ĐÃ ĐƯỢC ĐƯA VÀO ĐÚNG VỊ TRÍ)
        [HttpPost]
        public async Task<IActionResult> ChangeStatus(int id, string status)
        {
            var booking = await _context.Bookings.FindAsync(id);
            if (booking != null)
            {
                booking.Status = status;
                await _context.SaveChangesAsync();
            }
            return RedirectToAction(nameof(Index));
        }

        // GET: Bookings/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Bookings/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,CustomerName,Phone,Email,PickupDropoffLocation,TotalPrice,Status,BookingDate")] Booking booking)
        {
            if (ModelState.IsValid)
            {
                _context.Add(booking);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(booking);
        }

        // GET: Bookings/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null) return NotFound();

            var booking = await _context.Bookings.FindAsync(id);
            if (booking == null) return NotFound();
            return View(booking);
        }

        // POST: Bookings/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,CustomerName,Phone,Email,PickupDropoffLocation,TotalPrice,Status,BookingDate")] Booking booking)
        {
            if (id != booking.Id) return NotFound();

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(booking);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!BookingExists(booking.Id)) return NotFound();
                    else throw;
                }
                return RedirectToAction(nameof(Index));
            }
            return View(booking);
        }

        // GET: Bookings/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null) return NotFound();

            var booking = await _context.Bookings
                .FirstOrDefaultAsync(m => m.Id == id);
            if (booking == null) return NotFound();

            return View(booking);
        }

        // POST: Bookings/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var booking = await _context.Bookings.FindAsync(id);
            if (booking != null)
            {
                _context.Bookings.Remove(booking);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool BookingExists(int id)
        {
            return _context.Bookings.Any(e => e.Id == id);
        }
    }
}