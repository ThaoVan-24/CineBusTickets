using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using CineBusTickets.Models;
using Microsoft.EntityFrameworkCore;

namespace CineBusTickets.Controllers;

public class HomeController : Controller
{
    private readonly CineBusDbContext _context;

    // Tiêm DbContext vào để kết nối CSDL
    public HomeController(CineBusDbContext context)
    {
        _context = context;
    }

    // Hiển thị form tìm kiếm ở Trang chủ
    public async Task<IActionResult> Index()
    {
        // Lấy danh sách điểm đi và điểm đến duy nhất từ bảng Routes
        ViewBag.DeparturePlaces = await _context.Routes.Select(r => r.DeparturePlace).Distinct().ToListAsync();
        ViewBag.ArrivalPlaces = await _context.Routes.Select(r => r.ArrivalPlace).Distinct().ToListAsync();
        return View();
    }

    // Xử lý khi người dùng bấm nút "Tìm kiếm"
    // Xử lý khi người dùng bấm nút "Tìm kiếm"
    [HttpPost]
    public async Task<IActionResult> SearchTrips(string departurePlace, string arrivalPlace, DateOnly departureDate) // Đã sửa DateTime thành DateOnly
    {
        // Lọc các chuyến xe khớp với 3 điều kiện
        var trips = await _context.Trips
            .Include(t => t.Route)
            .Include(t => t.Bus)
            .Where(t => t.Route.DeparturePlace == departurePlace 
                     && t.Route.ArrivalPlace == arrivalPlace 
                     && t.DepartureDate == departureDate)
            .ToListAsync();

        // Truyền lại thông tin tìm kiếm sang View để hiển thị
        ViewBag.DepPlace = departurePlace;
        ViewBag.ArrPlace = arrivalPlace;
        ViewBag.DepDate = departureDate.ToString("dd/MM/yyyy");

        return View(trips);
    }

    public IActionResult Privacy()
    {
        return View();
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}