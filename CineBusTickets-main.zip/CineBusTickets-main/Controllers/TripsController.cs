using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using CineBusTickets.Models;

namespace CineBusTickets.Controllers
{
    public class TripsController : Controller
    {
        private readonly CineBusDbContext _context;

        public TripsController(CineBusDbContext context)
        {
            _context = context;
        }

        // GET: Trips
        public async Task<IActionResult> Index()
        {
            var cineBusDbContext = _context.Trips.Include(t => t.Bus).Include(t => t.Route);
            return View(await cineBusDbContext.ToListAsync());
        }

        // GET: Trips/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null) return NotFound();

            var trip = await _context.Trips
                .Include(t => t.Bus)
                .Include(t => t.Route)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (trip == null) return NotFound();

            return View(trip);
        }

        // HÀM HỖ TRỢ: Tạo danh sách dropdown đẹp mắt
        private void PrepareDropdowns(int? selectedBusId = null, int? selectedRouteId = null)
        {
            var routes = _context.Routes.Select(r => new {
                Id = r.Id,
                RouteName = r.DeparturePlace + " ➔ " + r.ArrivalPlace
            }).ToList();

            var buses = _context.Buses.Select(b => new {
                Id = b.Id,
                BusInfo = b.BusNumber + " (" + b.Category + " - " + b.TotalSeats + " chỗ)"
            }).ToList();

            ViewData["BusId"] = new SelectList(buses, "Id", "BusInfo", selectedBusId);
            ViewData["RouteId"] = new SelectList(routes, "Id", "RouteName", selectedRouteId);
        }

        // GET: Trips/Create
        public IActionResult Create()
        {
            PrepareDropdowns();
            return View();
        }

        // POST: Trips/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,RouteId,BusId,DepartureDate,DepartureTime,TicketPrice")] Trip trip)
        {
            ModelState.Remove("Bus");
            ModelState.Remove("Route");
            if (ModelState.IsValid)
            {
                var newRoute = await _context.Routes.FindAsync(trip.RouteId);
                if (newRoute == null) return NotFound();

                TimeSpan newTripStart = trip.DepartureTime.ToTimeSpan();
                TimeSpan newTripEnd = newTripStart.Add(TimeSpan.FromHours(newRoute.DurationEstimated));

                var existingTrips = await _context.Trips
                    .Include(t => t.Route)
                    .Where(t => t.BusId == trip.BusId && t.DepartureDate == trip.DepartureDate)
                    .ToListAsync();

                bool hasConflict = false;

                foreach (var existingTrip in existingTrips)
                {
                    TimeSpan existingStart = existingTrip.DepartureTime.ToTimeSpan();
                    TimeSpan existingEnd = existingStart.Add(TimeSpan.FromHours(existingTrip.Route.DurationEstimated));
                    
                    existingEnd = existingEnd.Add(TimeSpan.FromHours(1)); // Thêm 1 giờ quay đầu xe

                    if ((newTripStart >= existingStart && newTripStart < existingEnd) ||
                        (newTripEnd > existingStart && newTripEnd <= existingEnd) ||
                        (newTripStart <= existingStart && newTripEnd >= existingEnd))
                    {
                        hasConflict = true;
                        break;
                    }
                }

                if (hasConflict)
                {
                    ModelState.AddModelError(string.Empty, "Lỗi: Chiếc xe này đã có lịch chạy hoặc đang trong thời gian quay đầu vào khung giờ này! Vui lòng chọn xe hoặc đổi giờ.");
                    PrepareDropdowns(trip.BusId, trip.RouteId);
                    return View(trip);
                }

                _context.Add(trip);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            
            PrepareDropdowns(trip.BusId, trip.RouteId);
            return View(trip);
        }

        // GET: Trips/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null) return NotFound();

            var trip = await _context.Trips.FindAsync(id);
            if (trip == null) return NotFound();
            
            PrepareDropdowns(trip.BusId, trip.RouteId);
            return View(trip);
        }

        // POST: Trips/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,RouteId,BusId,DepartureDate,DepartureTime,TicketPrice")] Trip trip)
        {
            if (id != trip.Id) return NotFound();

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(trip);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!TripExists(trip.Id)) return NotFound();
                    else throw;
                }
                return RedirectToAction(nameof(Index));
            }
            PrepareDropdowns(trip.BusId, trip.RouteId);
            return View(trip);
        }

        // GET: Trips/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null) return NotFound();

            var trip = await _context.Trips
                .Include(t => t.Bus)
                .Include(t => t.Route)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (trip == null) return NotFound();

            return View(trip);
        }

        // POST: Trips/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            ModelState.Remove("Bus");
            ModelState.Remove("Route");
            var trip = await _context.Trips.FindAsync(id);
            if (trip != null)
            {
                _context.Trips.Remove(trip);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool TripExists(int id)
        {
            return _context.Trips.Any(e => e.Id == id);
        }
    }
}