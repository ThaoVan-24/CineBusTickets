﻿using System;
using System.Collections.Generic;

namespace CineBusTickets.Models;

public partial class BookingItem
{
    public int Id { get; set; }

    public int BookingId { get; set; }

    public int TripId { get; set; }

    public string SeatNumber { get; set; } = null!;

    public decimal Price { get; set; }

    public virtual Booking Booking { get; set; } = null!;

    public virtual Trip Trip { get; set; } = null!;
}
