﻿using System;
using System.Collections.Generic;

namespace CineBusTickets.Models;

public partial class Bus
{
    public int Id { get; set; }

    public string BusNumber { get; set; } = null!;

    public string Category { get; set; } = null!;

    public int TotalSeats { get; set; }

    public virtual ICollection<Trip> Trips { get; set; } = new List<Trip>();
}
