﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace CineBusTickets.Models;

public partial class CineBusDbContext : DbContext
{
    public CineBusDbContext()
    {
    }

    public CineBusDbContext(DbContextOptions<CineBusDbContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Booking> Bookings { get; set; }

    public virtual DbSet<BookingItem> BookingItems { get; set; }

    public virtual DbSet<Bus> Buses { get; set; }

    public virtual DbSet<Route> Routes { get; set; }

    public virtual DbSet<Trip> Trips { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Server=DESKTOP-K2RLLEG\\SQLEXPRESS;Database=CineBusDB;Trusted_Connection=True;TrustServerCertificate=True;");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Booking>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Bookings__3214EC072F1B8258");

            entity.Property(e => e.BookingDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime")
                .HasColumnName("Booking_Date");
            entity.Property(e => e.CustomerName)
                .HasMaxLength(100)
                .HasColumnName("Customer_Name");
            entity.Property(e => e.Email)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Phone)
                .HasMaxLength(15)
                .IsUnicode(false);
            entity.Property(e => e.PickupDropoffLocation)
                .HasMaxLength(255)
                .HasColumnName("Pickup_Dropoff_Location");
            entity.Property(e => e.Status)
                .HasMaxLength(50)
                .HasDefaultValue("Chờ thanh toán");
            entity.Property(e => e.TotalPrice)
                .HasColumnType("decimal(18, 2)")
                .HasColumnName("Total_Price");
        });

        modelBuilder.Entity<BookingItem>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Booking___3214EC0784ABEAA6");

            entity.ToTable("Booking_Items");

            entity.HasIndex(e => new { e.TripId, e.SeatNumber }, "UQ_Trip_Seat").IsUnique();

            entity.Property(e => e.BookingId).HasColumnName("Booking_Id");
            entity.Property(e => e.Price).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.SeatNumber)
                .HasMaxLength(10)
                .IsUnicode(false)
                .HasColumnName("Seat_Number");
            entity.Property(e => e.TripId).HasColumnName("Trip_Id");

            entity.HasOne(d => d.Booking).WithMany(p => p.BookingItems)
                .HasForeignKey(d => d.BookingId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Booking_I__Booki__44FF419A");

            entity.HasOne(d => d.Trip).WithMany(p => p.BookingItems)
                .HasForeignKey(d => d.TripId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Booking_I__Trip___45F365D3");
        });

        modelBuilder.Entity<Bus>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Buses__3214EC073D843ED0");

            entity.HasIndex(e => e.BusNumber, "UQ__Buses__8AC4D41BC2190E68").IsUnique();

            entity.Property(e => e.BusNumber)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasColumnName("Bus_Number");
            entity.Property(e => e.Category).HasMaxLength(50);
            entity.Property(e => e.TotalSeats).HasColumnName("Total_Seats");
        });

        modelBuilder.Entity<Route>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Routes__3214EC07D9764EB2");

            entity.Property(e => e.ArrivalPlace)
                .HasMaxLength(100)
                .HasColumnName("Arrival_Place");
            entity.Property(e => e.DeparturePlace)
                .HasMaxLength(100)
                .HasColumnName("Departure_Place");
            entity.Property(e => e.DurationEstimated).HasColumnName("Duration_Estimated");
        });

        modelBuilder.Entity<Trip>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Trips__3214EC07A7D72B2C");

            entity.Property(e => e.BusId).HasColumnName("Bus_Id");
            entity.Property(e => e.DepartureDate).HasColumnName("Departure_Date");
            entity.Property(e => e.DepartureTime).HasColumnName("Departure_Time");
            entity.Property(e => e.RouteId).HasColumnName("Route_Id");
            entity.Property(e => e.TicketPrice)
                .HasColumnType("decimal(18, 2)")
                .HasColumnName("Ticket_Price");

            entity.HasOne(d => d.Bus).WithMany(p => p.Trips)
                .HasForeignKey(d => d.BusId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Trips__Bus_Id__3D5E1FD2");

            entity.HasOne(d => d.Route).WithMany(p => p.Trips)
                .HasForeignKey(d => d.RouteId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Trips__Route_Id__3C69FB99");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
