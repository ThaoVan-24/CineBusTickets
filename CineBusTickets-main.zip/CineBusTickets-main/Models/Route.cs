﻿using System;
using System.Collections.Generic;

namespace CineBusTickets.Models;

public partial class Route
{
    public int Id { get; set; }

    public string DeparturePlace { get; set; } = null!;

    public string ArrivalPlace { get; set; } = null!;

    public double Distance { get; set; }

    public double DurationEstimated { get; set; }

    public virtual ICollection<Trip> Trips { get; set; } = new List<Trip>();
}
