﻿using System;
using System.Collections.Generic;

namespace CineBusTickets.Models;

public partial class Trip
{
    public int Id { get; set; }

    public int RouteId { get; set; }

    public int BusId { get; set; }

    public DateOnly DepartureDate { get; set; }

    public TimeOnly DepartureTime { get; set; }

    public decimal TicketPrice { get; set; }

    public virtual ICollection<BookingItem> BookingItems { get; set; } = new List<BookingItem>();

    public virtual Bus Bus { get; set; } = null!;

    public virtual Route Route { get; set; } = null!;
}
